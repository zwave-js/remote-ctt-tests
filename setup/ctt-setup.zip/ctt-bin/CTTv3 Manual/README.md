# Building the CTT Documentation

## Install Dependencies

Prerequisites for JEKYLL (see https://jekyllrb.com/docs/installation/windows/)

- Ruby+Devkit  (https://rubyinstaller.org/downloads/)
- Ruby gems
- MSYS2
- MINGW 
    
All is done by Ruby Installer. Please make sure that you choose the DEVKIT installer!

When all prerequisites are installed, open terminal and change to this directory.

Check installation of ruby by getting the version: 

    ruby -v

If ruby is not found, make sure to add `ruby-install-path/bin` to environment variables.

Then install all required packages running:

    bundle install

If the online source cannot be found, update first by

    bundle update


## Build the Manual

    bundle exec jekyll build

Then find the build within the `_site` directory. Open `index.html`.

### Options while developing the user manual:

1. Manually build on every change using

        bundle exec jekyll build

    or run `build.bat` which does exactly the same.

2. Build using watch options

        bundle exec jekyll --watch

    or run `build_and_watch.bat` which is just a shortcut for this.

3. Running a local web-server with livereload

        bundle exec jekyll serve --livereload

    or run `serve.bat`.
    
    With this option just open the URL http://localhost:4000/.
    
    Any changes will automatically be applied.