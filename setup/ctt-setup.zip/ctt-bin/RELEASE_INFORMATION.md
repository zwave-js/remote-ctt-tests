Z-Wave Compliance Test Tool (CTT) - Release Information
=======================================================

If you encounter any bug or issue with the CTT, please read the 'Known Issues'
and if not listed, contact:

- certadmin@z-wavealliance.org or
- support@mk-logic.de


CTT 3.10.10 (2025-08-25) [2025A]
================================

> NOTICE WHEN UPGRADING FROM EARLIER VERSIONS:
>
> Due to a new project system (version 4), CTT projects created or saved
> with CTT version 3.10.4 or newer are not compatible with older CTT versions
> (project system 3 or older) anymore. Whereas, old projects can still be
> opened with the current CTT and will automatically be migrated to the latest
> project system after confirmation by the user.

NEW:

- Added `CTT-Remote.exe` as a command line tool which provides a JRPC
  Websockets-based interface for remote control. For further information,
  please refer to the `CTT-Remote.md` in the installation folder or CTT-Remote
  project folder.
- Added support for IP devices.
- Project system, version 4: Added minor versions (sub-revisions) for CTT
  scripts allowing to deliver fixes for bugs or breaking XML changes for
  existing revisions (i.e. necessary changes for older cert programs).
- Automatically write HTML log for every script run and ZATS test run. 
- Added project lock mechanism in order to open a particular project only once.
- Allow single scripts to be added from `.cttc.tcl` files.
- Start page improvement: Allow to delete projects that do not exist anymore
  from the 'Recent Projects'.
- Script language: GETBYTESTRING and GETSTRINGBYTES: Added options for OEM
  Extended ASCII (Code Page 437) and UTF-16 with big endian or little endian
  order each.
- Create CTT components package (Oficcial Solution, ZATS Cert Tests etc.) in
  GitHub action.

CHANGED:

- Updated CTT components in accordance with cert program 2025A to the following
  versions:
  - Z-Wave Plus Resources (Configuration Files): 10
  - ZATS Test Console: 16
  - ZATS Cert Test Cases: 22
  - Official CTT Script Solution (OSV): 42
    - Minimum CTT version is 3.10.4 due to breaking changes in Z-Wave XML.
- Clarified package versions within the CTT Version Info XML.
- Zniffers of type 'Zniffer PTI' are now maintained via 'Manage IP Devices'.
  Their auto-detection has been removed accordingly.
- CTT Main Controller:
  - Use actual (flashed) private key / public key and hence DSK.
  - Use Generic Controller Device Type (ZWPv2).
- Made DUT interview data available in the UI during test run.
- Focus 'Error List' when script compile errors occur.
- Script whitespace: At saving replace tabs and remove trailing spaces.
- Remove trailing slash from Portal URLs.
- Search for updates: Warn when no credentials are entered for the portal
  connection.
- Advanced Inclusion: Hide 'Is SUC Capable' that did not always work as
  expected.
- Moved CTT to root directory.
- Adapted repository structure of ZWA and moved all projects into one solution:
  - Renamed `Libraries/ZWaveDLL` to `Libraries/z-wave-tools-core` and aligned
    contents with ZWA repo.
  - Moved `ZATS` into `Libraries`. Renamed it to `z-wave-automated-test-system`
    and aligned contents with ZWA repo.
  - Extracted `CertTestCases` and `ZatsDataTransfer` from ZATS and moved into
    root folder.
  - Built single `ZWaveCTT` solution which integrates everything (no separate
    `ZatsCert` solution needed anymore).
  - Adapted Readme, build scripts, setup and GitGub actions accordingly.
- Moved `Libraries/z-wave-blobs`, `Libraries/z-wave-tools-core` and
  `z-wave-automated-test-system` out of CTT repository and include them as
  submodules pointing to their branches `main-mkl` each.
- Extended setup adding publisher and estimated size to 'Apps'. 
- Extracted ScriptLogUtils from regular LogUtils. Equalized warnings (vs.
  errors).
- Updated documentation.
- Check that Role Type and Device Type XMLs are present.
- Tools Core: Strorage Writer: Create file directory if it does not exist.
- Adjusted GitHub workflows and .gitignore.

FIXED:

- Open Zniffer traces with spaces in the file path. Added workaround for ' -'
  character combination so that PC Zniffer app will not interpret it as
  parameters.
- CTT Main Controller: Fixed missing version of Inclusion Controller CC.
- Fixed 'Run all selected Tests' for LR scripts tab.
- Fixed default layout issues.
- Script language: Fixed GETBYTESTRING and GETSTRINGBYTES for UTF-16
  considering that in Z-Wave typically big endian order is used (all official
  scripts were checked).
- Fixed Portal URL for DUT-based projects in alpha and beta versions as needed
  for Wiki links.
- Installer: Uninstall existing CTT version only when installation itself has
  been confirmed. Wait for uninstallation to be completed before installing.
- Fixed CTTSLN files XML header that said UTF-16 despite being UTF-8.
- Fixed order of test case update and plausibility check.
- Missing warning messages and line breaks, typos and line endings.

Z-Wave Plus Resources, version 10
---------------------------------

- DUT-based test lists updated.

ZATS Test Console, version 16
-----------------------------

NEW:

- Evaluation for Controller SAPI with SmartStart Learn Mode.

CHANGED:

- Updated Z-Wave XML to version 2.16.0. Adjusted User Credential CC-specific
  XML changes.
- User Code CC support implementation: Enable User Code Messaging Status in
  order to keep compatibility to User Credential PIN Code mapping.
- User Credential CC (U3C) support implementation:
  - Added User Credential Association Report to the list of mandatory Lifeline
    commands in accordance with spec 2025A.
  - Reworked regarding introduced advertisement of 'User Name Encoding'
    capabilities. 
  - Clarified that OEM Extended ASCII is Code Page 437. Moved string encodings
    from U3C tests and support implementation to Z-Wave Tools Core.
- Use random default values for Manufacturer CC and Version CC data when
  emulating devices.

FIXED:

- Fixed static port for Zniffer PTI in ZATS (ZatsDefinition has no port for the
  Zniffer).
- Meter CC support implementation:
  - Non-accumulated values shall not be reset. Considered the accumulating
    attribute for scalings dependent on the meter type.
  - Omit 'Previous Meter Value' field when delta time is 0.
- Notification CC support implementation: Advertise unknown types and events.

ZATS Cert Test Cases, version 22
--------------------------------

NEW:

- CCA_U3CReportUserCredAssoc_Rev01:
  - New test for checking User Credential Association Report being sent to the
    Lifeline.
  - Considered whether a Cred Type can be set via Z-Wave.
- CSR_LifelineMandatoryReports_Rev04: New revision for 2025A adding User
  Credential Association Report.
- CSR_SupervisionEncapViaAssociation_Rev03: New revision with updated
  requirements.
- H_RadioRangeZW_Rev02 and H_RadioRangeZWLR_Rev02: New revisions considering
  new tags for the radio range.
- RD_UserCredentialCC_Rev01: New docu test considering credential types that
  cannot be added or modified via Credential Set.

CHANGED:

- CCA_U3C...: Reworked User Credential CC tests making sure to use actually
  supported user name encodings as introduced with spec version 2025A:
  - CCA_U3CChecksums_Rev01
  - CCA_U3CEnterCredentials_Rev01
  - CCA_U3CLearnCredentials_Rev01
  - CCA_U3CReportCredentialData_Rev01
  - CCA_U3CReportUserCredAssoc_Rev01
  - CCA_U3CReportUserData_Rev01
- CCA_U3C...: Reworked User Credential CC tests making sure to only set
  credential data for types that support it (was made easier with spec version
  2025A):
  - CCA_U3CChecksums_Rev01
  - CCA_U3CEnterCredentials_Rev01
  - CCA_U3CReportAdminPinCodeData_Rev01
  - CCA_U3CReportCredentialData_Rev01
  - CCA_U3CReportUserCredAssoc_Rev01
- CCA_U3CLearnCredentials_Rev01: Increased TIME_MS_FOR_CL_STATUS_REPORT to 4 s.
- CCA_U3CReportCredentialData_Rev01: Added test "Credential (Bulk-Delete All) 
  Unchanged" that always applies, even when there is no credential type that
  allows adding credentials via Z-Wave (as introduced with spec version 2025A).
- CCR_UserCredentialCC_Rev01:
  - Advertise all supported User Name Encodings within the User Capabilities
    Report.
  - Verify displaying user data in UI when receiving an unsolicited User
    Report, e.g. the user name encoded with OEM Extended ASCII or UTF-16BE, the
    User Active State, User Type, Credential Rule, Expiring Timeout Minutes and
    User Modifier.
- CDR_ResetWithoutDelivery_Rev01: When looking for Transfer Presentations from 
  controller DUTs: Collect a bit longer.
- CSR_LifelineMandatoryReports_Rev03/04: Reworked to consider User Credential
  CC capabilities for valid test values (including user name encoding
  capabilities advertisement as introduced with spec version 2025A).
- Adopted changes of Z-Wave XML 2.16.1 and its generated CCsd. Accordingly, 
  removed User Credential Association Destination Slot in:
  - CCA_U3CReportUserCredAssoc_Rev01
  - CSR_LifelineMandatoryReports_Rev04
- Refactored getting capabilities per End Point.
- Moved common messages to base class. Refactored constants.
- VerifyTriggeredCmds: Refactored.
- Added an evaluation ZATS test case provoking an exception – for testing only!
- Added check for major version consistency to build process. Require test case
  group, category and description attributes.

FIXED:

- CCA_U3C tests: Made sure results are set to pending when test is aborted.
- CCR_MeterCC_Rev01/02:
  - Non-accumulated values shall not be reset.
  - Omit 'Previous Meter Value' field when delta time is 0.
- CCR_MultilevelSensorCC_Rev02: Fixed typo that said 'Multilevel Switch'
  instead of 'Multilevel Sensor'.
- CCR_NotificationCC_Rev01/02/03/04: Fixed testing receiving unsolicited
  notifications considering that states can be reset to 'idle', whereas, events
  cannot.
- CCR_NotificationCC_Rev04: Advertise unknown types and events for version 8.
- CCR_ThermostatModeCC_Rev01/02: Added missing differentiation between
  controlled versions 1 to 3 regarding controlled thermostat modes.
- CDR_ResetWithoutDelivery_Rev01: Fixed typo in error message when looking for
  Transfer Presentations from Node ID 1 for controller DUTs.
- CSR_LifelineMandatoryReports_Rev04: For Long Range consider that some DUTs
  may not have a local trigger so that no state change can be caused.
- Prevent asking to skip a test case while already finalizing the test.
- Fixed typos.

Official CTT Script Solution (OSV), version 42
----------------------------------------------

NEW:

- GeographicLocationCmdClassV2_Rev01: Initial release for spot-checking in cert
  program 2025A setting realistic values if possible.
- NodeNamingandLocationCmdClassV1_Rev02: New revision that uses and checks for
  omitted field when deleting / deleted.

CHANGED:

- Updated Z-Wave XML to version 2.16.1.
- UserCredentialCmdClassV1_Rev01:
  - Reworked 'UserCredentialAssociation': Removed tests for Destination Slot
    and rename 'Source Slot' in accordance with breaking changes of spec 2025A
    (previous versions of User Credential Association had never been
    certified).
  - Reworked 'SetInitialValuesAndVariables': Changed 'VG1' to
    'SupportedUserTypes' property due to updated Z-Wave XML.
  - Reworked setting credentials making sure Credential Min/Max Length equal 0
    is considered in accordance with spec 2025A, i.e. in this case credentials
    of that Credential Type cannot be added or modified via Z-Wave.
  - Reworked setting user names considering that with spec version 2025A not
    all encodings are required to be supported anymore.
  - 'SetUserIncorrectly': Clarified the recommendation regarding the default
    user name.
  - 'GetCredential': Clarified skipped tests.
  - Clarified and hardened preconditions for Admin PIN Code tests.
  - Added double-check making sure that Active Schedule CC is not part of cert
    program 2025A.
  - Minor refactoring.

FIXED:

- IndicatorCmdClassV3_Rev10/V4_Rev06: Sequence 'IndividualValuesNodeIdentify':
  Fixed consideration of returned Property 0x05 values when value 0x00 (i.e.
  half of Property 0x03) was set.
- Whitespace adjusted.


CTT 3.9.3 (2025-03-12) [2024B-3]
================================

> NOTICE:
>
> The recommended firmware version for all CTT devices is now the Silabs Z-Wave
> SDK 7.23.1 on 800 series as it supports EU_LR with its shifted LR
> frequencies. 7.22 will no longer be valid for EU_LR. Refer to
> `[User]\Documents\Z-Wave Alliance\Z-Wave CTT 3\CTT Device Firmwares`.

CHANGED:

- Updated FW for CTT hardware. Recommended version is Silabs Z-Wave SDK 7.23.1
  on 800 series.
- Require Silabs Z-Wave SDK 7.23 or higher for CTT devices running RF region
  EU_LR due to obsoleted LR frequencies used in 7.22.
- Updated CTT component "ZATS" to version 14 and CTT Scripts to version 39
  (actual scripts as well as ZWP Resources and ZATS Cert Tests are unchanged.)

CTT ZATS 14 / ZATS Cert Tests 18
--------------------------------

CHANGED:

- Zniffer requires firmware version 10.23 (Silabs Z-Wave SDK 7.23) or higher
  for RF region EU_LR due to obsoleted LR frequencies used in 10.22 (SDK 7.22).

CTT Scripts 39
--------------

FIXED:

- Fixed Official Solution: When it was opened separately as CTT project (e.g.
  for export), it had removed script code from TimeCmdClassV2_Rev03 and
  UserCredentialCmdClassV1_Rev01.


CTT 3.9.1 (2025-01-15) [2024B-2]
================================

> NOTICE:
>
> The recommended Zniffer type is now the 'NCP Zniffer' as it supports setting
> the LR channel configuration via its API.
>
> The recommended firmware version for all CTT devices is now the Silabs Z-Wave
> SDK 7.22.2 on 800 series as it supports EU_LR. Refer to
> `[User]\Documents\Z-Wave Alliance\Z-Wave CTT 3\CTT Device Firmwares`.
> However, please also note the discussed frequency shift for EU_LR. Refer to
> the Z-Wave Alliance’s Core Stack Working Group (CSWG).

NEW:

- Added support for RF region 'EU_LR'.
- Added selection of LR channel. Is considered in CTT Controller SAPI and the
  the Zniffer configuration is derived accordingly (all classic channels and
  the one selected LR channel). 
- Added support for NCP Zniffer as LR Zniffer (for both in CTT and ZATS tests).

CHANGED:

- Updated CTT components including fixes and new tests in accordance with
  cert program 2024B-2 to the following versions:
  - ZWP Resources: 9
  - ZATS: 13
  - ZATS Cert Tests: 18
  - CTT Scripts: 38 (minimum CTT version still 3.8.0)
- Updated Z-Wave DLL.
- Reworked setting RF regions considering different versions of serial APIs
  (500/700/800 series; support for LR and specific LR regions; channel
  configuration availability).
- Updated FW for CTT hardware. Recommended version is 7.22.2.
- Split 'Release Information' and 'Known Issues'. Converted to markdown.
- Updated documentation regarding CTT hardware, LR channel selection and NCP
  Zniffer vs. PTI Zniffer.

FIXED:

- Auto-Update: Do not close CTT if download of setup.exe did not work. Prevents
  the 'File is used by another process' exception.
- Fixed exclusion mode for LR.
- ZnifferManager: Fixed finding frequency code by RF region.

Z-Wave Plus Resources 9
-----------------------

CHANGED:

- DUT-based 'Mini-Form' updated for new tests and considering Certified
  Software Designs.

CTT ZATS 13 / ZATS Cert Tests 18
--------------------------------

NEW:

- ZATS Test Runner: Added option to choose LR channel in ZATS for Zniffer
  (configuration is derived accordingly: all classic channels and the one
  selected LR channel) and in CertTestCases also for the ZATS Controller.
- ZatsTestConsole: Added option to wait for debugger during development.
- CR_CertifiedSoftwareDesignBase_Rev01: New test for when no Certified SW
  Design has been used or it is modified.
- H_RadioRangeZW_Rev01 / H_RadioRangeZWLR_Rev01: New tests considering
  benchmark range testing. 

CHANGED:

- Merged Silabs ZATS 2.2.1.54 as of 2024-07-18 but fixed Transport Service by
  removing the case for SendDataExOperation again.
- Merged ZATS from EDE back into CTT.
- ZATS Test Runner: Updated RF regions also considering 'EU_LR'.
- User Credential CC Support: Improved considering MC Bit Addressing and do not
  deny "Auto-Report" due to Set-type command with Broadcast or Multicast for
  this is not specified.
- User Credential CC Support: Removed old (ambiguous) development option to not
  use credential hashing, even if required (when CRB is 0).
- Improved using CRC16 calculation from ZWaveDLL considering payload length can
  exceed 255 bytes by far.
- CCA_U3CReportUserData_Rev01: Added verification for different Modifier Node
  ID. 
- CSR_MCSupportPrimaryFuncOnEP1_Rev01: Improved the question.
- LR channel configuration is considered in test cases:
  - LR_CanJoinLRNetwork_Rev02 (verifies LR channels A and B)
  - LR_FailingInclusionWithoutAuthentication_Rev02
  - LR_IdenticalCapabilitiesInClassicAndLRNetwork_Rev02
  - LR_RequestedKeys_Rev02
- PI_CertificationData_Rev01: Consider 'Certified Software Designs' on
  'Certification Data' overview page.
- RT_CSCMustSupportS0AndS2_Rev01: Improved checking for S0-encapsulated
  communication. Added a way to manually retry. Enhanced test perspectives by
  S0 bootstrapping and non-secure inclusion.
- RT_CSCWakeUpConfigPENIfSIS_Rev01 and RT_CSCWakeUpConfigPSIfSIS_Rev01/02:
  Increased timeout waiting for controlling Wake Up commands.

FIXED:

- Fixed shown Zniffer RF configuration in console output.
- CC Support: Considered Multi Channel Bit Addressing for all CC support
  implementations.
- User Credential CC Support: Handle Supervision Report correctly when User
  Name Length has been set to zero. Consider User Name for Add / Modify only.
- CCR_EntryControlCC_Rev01/02/03: Fixed typo. 
- CCR_MultiChannelAssociationCC_Rev02: Added Multi Channel Support to ZATS
  Controller device.
- CCR_ThermostatSetbackCC_Rev01/02 / CC Support: Fixed exception if large byte
  values (e.g. 0xFC) are sent as Setback State to the ZATS end device. Added
  'Kelvin' to log output. Using byte in function signatures instead of object.
- CCR_ThermostatSetpointCC_Rev01/02/03: Fixed empty Thermostat Mode Supported
  Report by adding according support data. Fixed typo. 
- CDR_EncapOrder_Rev02: Fixed missing CRC16 and Transport CCs in NIF.
- CSR_MCSupportPrimaryFuncOnEP1_Rev01: Fixed DUT-based run. Fixed ZCP-based
  input keys.
- RT_CSCMustSupportS0AndS2_Rev01: Fixed run for S0 outcome via S2 bootstrapping
  by preventing the issue where the End Device Serial API does not answer a KEX
  Get.
- S2_SupportedCCRequirement_Rev01/02: Use correct Supervision values for
  parameter 'Encapsulated Command'.

CTT Scripts 38
--------------

NEW:

- TimeCmdClassV2_Rev03: New script revision added. Reworked Start and End DST
  for Month / Day / Hour in order to allow having no Day Saving Time as of spec
  2024B.

FIXED:

- UserCredentialCmdClassV1_Rev01:
  - Fixed User Name creation during script init. 
  - Added missing wait times after set commands waiting for auto-reports.
  - Fixed sequences:
    - 'UserCredentialAssociation'
    - 'AdminCodeDuplicateDetection'
    - 'SetCredentialIncorrectly'


CTT 3.8.2 (2024-10-30) [2024B-1]
================================

CHANGED:

- Updated CTT components including fixes and new tests in accordance with cert
  program 2024B-1 to the following versions:
  - ZWP Resources: v8 (including DUT-based 'Mini-Form' updated for 2024B-1)
  - ZATS: v11
  - ZATS Cert Tests: v16
  - CTT Scripts: v36 (minimum CTT version 3.8.0 due to breaking changes within
    Z-Wave XML)
- Updated Z-Wave XML to version 2.15.2 (ZWaveDLL, ZATS, Official CTT Scripts
  Solution) including generated C# classes (skipped the broken ones which are
  to be fixed in Z-Wave XML and/or its editor / generator).
- Reworked SerialDeviceDetector to store more information of Zniffers and show
  devices equally.
- Setting region: Double-check RF region by reading it back. Decide between
  Simplicity Commander and Serial API Setup Operation at one single place.
  Allow to set the region for Zniffer NCP via Simplicity Commander if needed.
- Updated CTT documentation.
- Improved wording of welcome text.

FIXED:

- Fixed setting RF region via IP address (if any, e.g. Zniffer PTI).
- Fixed meta data in setup file.
- Prevent CTT from getting stuck if result file is missing or broken.

CTT ZATS 11 / ZATS Cert Tests 16
--------------------------------

NEW:

- Test case base class: Added User Credential CC to known Application Command
  Classes.
- Test case base class: Added helper and wrapper functions.
- Added User Credential CC support-side tests:
  - CCA_U3CChecksums_Rev01
  - CCA_U3CEnterCredentials_Rev01
  - CCA_U3CLearnCredentials_Rev01
  - CCA_U3CReportAdminPinCodeData_Rev01
  - CCA_U3CReportCredentialData_Rev01
  - CCA_U3CReportUserData_Rev01
- CSR_LifelineMandatoryReports_Rev03: New revision added considering User
  Credential CC.
- CCR_UserCredentialCC_Rev01 (control-side test) added.

CHANGED:

- Moved several common functions from test cases to their base class.
- Equalized test case log messages referring to CTT menus.
- Completely reworked support implementation for User Credential CC.
- Removed obsoleted (removed) U3C-specific Notification events.

FIXED:

- ZWaveDLL: ApiAchOperation: Fixed considering Multi Channel Bit Addressing.
- ZWaveDLL: Fixed byte array to int converters influencing source data.
- CC Support Implementations: Fixed considering Multi Channel Bit Addressing in
  Door Lock, Multi Channel, Notification and User Credential CC
  implementations.
- Test case base class: Fixed timeout in RequestDataWrapper.
- Test case base class: Fixed GetHexString() that could influence original
  data.
- Test case base class, CSR_WakeUpManualTrigger_Rev01 and
  SSR_LearnModeFallback_Rev02: Potential fix using Service.ExpectData().
- CCR_MultiChannelAssociationCC_Rev02: Fixed log.
- S2C: Fixed possible exceptions in S2C tests.
- S2C_02599_FailingKeyExchange_Rev01:
  - Fixed ZATS controller that advertises Supervision CC to actually support
    it.
  - Step 2.3: Fixed requested keys to not contain S2_Access in order to allow
    deselecting all (if possible).
  - Step 2.4: Fixed keys to what was said.

CTT Scripts 36
--------------

CHANGED:

- UserCredentialCmdClassV1_Rev01 has been published.


CTT 3.7.1 (2024-07-25) [2024A]
==============================

NEW:

- CTT Auto-Update has been implemented.
- Double-clicking CTT project files will open them within CTT.

CHANGED:

- Updated CTT components including fixes and new tests in accordance with
  cert program 2024A to the following versions:
  - ZWP Resources: v7 (including DUT-based 'Mini-Form' updated for 2024A)
  - ZATS: v9
  - ZATS Cert Tests: v14
  - CTT Scripts: v34 (minimum CTT version 3.7 due to breaking changes within
    Z-Wave XML)
- Updated Z-Wave XML to version 2.14.6 (ZWaveDLL, ZATS, Official CTT Scripts
  Solution) including generated C# classes (skipped the broken ones which are
  to be fixed in Z-Wave XML and/or its editor / generator).
- DUT Interview: Added warnings when advertised security CCs do not match
  supported security schemes.
- CTT user scripts: Reworked script compiling and execution to focus error
  view in case of any compile errors.
- CTT scripts differ: Save and restore position and size of diff window.
- View of 'Mini-Form' in DUT-based projects: Moved buttons.
- Implemented progress bar when reflecting all ZATS tests (only the case when
  updating this component while the meta data list is missing).
- Re-arranged portal connections.
- Reworked documentation regarding required hardware. Improved description for
  Zniffer PTI (still needed for Long Range in this CTT version).
- Updated license information and extended installer to distribute this file.
- Package maintenance: Changed suggested export destination for 'Official CTT
  Solution' packages to a separate folder. Made exported 'Version XML'
  considering CTT-internal values for portal connections as source of truth
  rather than those downloaded from a server.

FIXED:

- Fixed exception in 'Test Case Log History' when opening a foreign project.
- Fixed exception when using 'Advanced Inclusion' dialog.
- Fixed CTT not being able to access component downloads via SAML.
- Fixed typo in CTT resources path.
- Fixed using correct 'ZATS Tests' package version during components update.
- Script maintenance: Fixed a bug where new original scripts could not be
  added to the 'Official CTT Script Solution'.
- Fixed version string in 'About' dialog considering alpha and beta versions.

CTT ZATS 9 / ZATS Cert Tests 14
-------------------------------

NEW:

- Implementation of Schedule Entry Lock CC support emulation.
- Implementation of User Credential CC support emulation. Includes
  interactions with Door Lock, Schedule Entry Lock and User Code CC support
  emulations.
- Introduced 'SpecVersion' and 'CertProgramVersion' for ZATS test cases (used
  in new and adjusted tests).
- CCT_CRC16EncapsulationCmdClassV1_Rev02 derived from Rev01. Reworked to
  automate or skip some sub-tests if tested elsewhere already.
- CSR_AssociationsSecurityLearning_Rev01 created for Av4/MCAv5, derived from
  Av3/MCAv4 test CSR_ControlViaAssociationSecurityLearning_Rev01.
- CSR_AssocV4OrMCAV5IsSupported_Rev01 created, derived from
  CSR_AssocV3OrMCAV4IsSupported_Rev01.

CHANGED:

- Merged ZATS and Z-Wave DLL from Z-Wave End Device Emulator (EDE) into CTT
  containing all the adjustments made for the 'Command Class Support
  Implementations' (emulations) in EDE. This affects all tests where a CTT
  (end) device makes use of these CC emulations.
- Improved log text when data of Static Controller is missing.
- Association and Multi Channel Association CC support emulations: Increased
  maximum selectable CC versions to Av4/MCAv5 (even though automatic Security
  Learning had not been implemented).
- Barrier Operator CC support emulation, CCR_BarrierOperationCC_Rev01/02/03,
  CSR_LifelineMandatoryReports_Rev01 and 02: Adapted breaking changes of
  Z-Wave XML 2.14 for Barrier Operator CC command names.
- CCR_BarrierOperatorCC_Rev03: Few delays added.
- CCR_Security2CC_Rev02: Deprecated manual CCR test for Security 2 when
  already tested elsewhere.
- CCR_UserCodeCC_Rev04: Show both User ID and current User Code in log when
  asking to modify the existing User Code as clarified by AWG. Added back
  testing a new User Code but on any unused User ID, in contrast to modifying
  existing ones.
- CDR_UseOfMultiCommandEncap_Rev01: Skipped unnecessary sub-tests.
- CR_AssignReturnRoutesIfSISIsPresent_Rev01: Skipped when already tested for
  CSC (Inclusion Controller side).
- CR_LifelineDestinationNodeId_Rev01: Skip test for CSC and RPC since already
  tested in other tests.
- H_RangeTestLongRange_Rev01: Clarified that the LR range test is meant for
  all LR channels.
- RT_CSCLifelineConfigIfNotSIS_Rev01/02, RT_CSCLifelineConfigIfSIS_Rev01/02,
  RT_CSCMustAcceptSISRole_Rev02/03: Adapted breaking changes of Z-Wave XML
  2.14 for Assign SUC Return Route command field name 'NodeID'.
- S2_PrimaryMayPerformS2Bootstrap_Rev01: Consider form selection 'Yes' or 'No'
  if available.
- SSR_CanBeIncludedUsingSmartStart_Rev02 and SSR_CanPerformSmartStartInclusion
  _Rev01: Write key results from actual SmartStart tests in order to replace
  the Form integrity test (RT_SupportedSmartStartFunctionality_Rev01).
- SSR_ResetAfterS2BootstrapError_Rev03: Increased expect timeouts by 20
  seconds.
- Manual tests referring to Wiki pages are using new Wiki URL structure.

FIXED:

- User Code support emulation: Fixed duplicated User Code handling.
- CCR_MeterCC_Rev01/02: Fixed scales within unsolicited Meter Reports.
- CCR_MeterCC_Rev02: Fixed unsolicited report after Meter Reset not sending to
  trigger node.
- CCR_UserCodeCC_Rev03/04: Fixed supporting node to not have duplicated user
  codes.
- CCR_WakeUpCC_Rev01/02: Made sure the CTT End Dev's Wake Up destination is
  not set before including it.
- CDR_UseOfMultiCommandEncap_Rev01 result handling fixed.
- CSR_AssocV3OrMCAV4IsSupported_Rev01: Fixed requirement text. Consider
  changed CCs as input key.
- CSR_LifelineMandatoryReports_Rev02, CSR_LifelineReportToMultipleNodes_Rev01
  and CSR_LifelineReportTriggeredByZWave_Rev01: Door Lock CC: Fixed
  configuring door handles that had no impact. Use Operation Type = Constant
  for both preparation and trigger commands.
- S2C_02563_WrongKEXReport_Rev01/02/V2_Rev01: Fixed verification of #2 tests
  (DUT includes CTT) which had always been passing.
- S2C_02572_MsgEncapMPANExtension_Rev01, S2C_02573_MsgEncapMPANExtMoreToFollow
  _Rev01, S2C_02576_MsgEncapMOSExtension_Rev01: Prevented possible exceptions.
- S2C_02574_MsgEncapMPANExtGroupID_Rev01: Fixed test setup so that both CTT
  controllers know of and understand each other even with newer serial API
  versions.
- S2C_02575_MsgEncapMGRPExtension_Rev01: Fixed steps 8/9/10 which did not
  verify anything if no re-sync had been requested at all. Fixed order of
  verification: Prefer S2 Msg over S2 Nonce. Prevented possible exceptions.
- S2C_02583_NetworkKeyGet_Rev01: Replaced not working S2 Multicast test with
  actual non-secure test. Improved workflow. Added possibility to skip steps
  for testing.
- S2C_02600_BootstrappingInterruptPoints_Rev01: Fixed KEX FAIL (Cancel)
  command in step 1.8 and send it when S2 bootstrapping is already ongoing.
  Removed non-answering CRC16 CC from CTT Controller.

CTT Scripts 34
--------------

NEW:

- AssociationCmdClassV4_Rev01 created, derived from V3 Rev04.
- BatteryCmdClassV1_Rev07/V2_Rev06/V3_Rev05: New revisions considering that as
  of 2024A the battery level 0xFF (low battery) must only be sent unsolicited.
  Also implemented retries for 'Interactive_WaitForBatteryLowReport'.
- IndicatorCmdClassV3_Rev10/V4_Rev06: New revisions. Refactored
  'IndividualValuesNodeIdentify' as standalone test considering recommended
  report values for set value 0x00 in property 5 ('On time within an On/Off
  period') as clarified in spec version 2024A.
- MultiChannelAssociationCmdClassV5_Rev01 created, derived from V4 Rev06.
- UserCredentialCmdClassV1_Rev01: Draft of User Credential CC script is work
  in progress.

CHANGED:

- BarrierOperatorCmdClassV1_Rev01/02/03: Adapted renamed command names
  'EventSignalSet', 'EventSignalingGet' and 'EventSignalingReport' within
  script revision each due to breaking changes in Z-Wave XML 2.14.


CTT 3.6.1 (2024-01-04) [2023B]
==============================

NEW:

- Added capability to transfer Product Name, Model Number and Cert ID from
  CTT to ZATS tests.

CHANGED:

- Updated CTT ZATS Tests to version 12 and CTT Scripts to version 33
  including fixes and new tests in accordance with cert program 2023B.
- Increased RequestTimeoutMs in Z-Wave DLL (NetworkViewPoint) to more than
  one second. Affects both CTT and ZATS tests. This should fix the sometimes
  occurring issue where some steps of Security Learning were aborted.
- Improved DUT Interview: Get Z-Wave Software Report (if any) for 'Protocol'
  and 'Application' sub-sub versions each. Distinguish requested security
  schemes vs. finally supported security schemes and active security scheme.
- Use default exclusion mode within CTT (like in ZATS).
- Use Z-Wave Alliance logo instead of Z-Wave logo.
- Show up to 24 recent projects.
- Use the user’s credentials of the respective cert portal when looking for
  CTT updates.

FIXED:

- Fixed updating ZWave_CTT_CommandClasses.cttxml.
- Fixed considering that primary vs. alternative update URL are not
  necessarily based on ZWA ZCP vs. Legacy Portal. Use centrally maintained
  server URLs.

CTT ZATS 7 / ZATS Cert Tests 12
-------------------------------

NEW:

- CCR_NotificationCC_Rev04: New revision. Added testing new events as of
  2023B. Added testing unknown types and events. Added testing recommended
  ability to configure rules based on notifications. Added testing
  recommended capability to update list of known notifications.
- CCR_UserCodeCC_Rev04: New test in accordance with 2023B interview
  requirements (CL:0063.01.21.02.3, CL:0063.01.21.03.1, CL:0063.01.22.01.1).
- CR_MinimumControlFunctionality_Rev02: New test revision considering the
  test is now always selected in the ZCP Form for controllers.
- DT_IRRepeaterNoAddSuppCCs_Rev01 and DT_RepeaterNoAddSuppApplicationCCs
  _Rev01 inherited from DT_MandatoryNotSupportedCCs_Rev01.
  DT_RepeaterNoAddSuppApplicationCCs_Rev01: Check for Application CCs, allow
  others.
- PI_CertificationData_Rev01 created for Certification Data comparison.
- RD_SmartStart_Rev02: New revision for 2023B.
- S2_NLSNotDeactivatable_Rev02: New revision in order to replace a
  duplicated requirement number in accordance with spec version 2023B.

CHANGED:

- General: Show full DSK of joining node during inclusion.
- General: Whitespace: Removed non-breaking space.
- CC Support Utils: Reworked and added method for getting human readable
  names for notification types and events also considering unknown (not yet
  defined) values.
- Notification Support: Added new events. Allow emulating unknown events.

FIXED:

- Base class: Sort security schemes in human readable string.
- CCA_NotificationCmdClassBackwards_Rev01/..V8Backwards_Rev01: Fixed test
  case group.
- CCR_NotificationCC_Rev01, Rev02, Rev03: Fixed typos and adapted changes in
  CC Support Utils. Rev03: Fixed verification of Alarm Get (Pull nodes).
- CCR_UserCodeCC_Rev03: Added missing observation of v1 User Code Set in v2
  test sequence. Made sure user code slots are not empty for User IDs which
  shall be modified by the DUT later on. Fixed possible exceptions. Added
  missing requirement number.
- CCR_SoundSwitchCC_Rev02: Fixed requirement number.
- CR_MinimumControlFunctionality_Rev01: Fixed verification in case there are
  no controlled CCs found in the ZCP Form.
- CSR_LifelineMandatoryReports_Rev02: Skip Central Scene Configuration Report
  when not applicable.
- CSR_LifelineReportTriggeredByZWave_Rev01 and
  CSR_LifelineReportToMultipleNodes_Rev01: Fixed MCA Set by emptying the
  NodeID field (before the marker) in order to remove the duplicated entry.
  Reworked verification of inclusions. Removed Association in favor of MCA.
  Explicitly added return route assignment for ZatsEndDev to DUT.
- DT_MandatoryNotSupportedCCs_Rev01 fixed: Test all End Points. Consider
  matching Device Types only.
- RT_CSCMustAcceptSISRole_Rev03 and 02: Fixed workaround for avoiding
  Supervision-encap for frame watching by Zniffer. Increased Zniffer timeout.
  Rev03: Wait for DUT to be ready before requesting Add Mode.
- S0_DelaySchemeReportAfterSchemeInherit_Rev01: Wait manually before sending
  S0 Cmds Supp Get.
- S0_EndDeviceCanBeS0Included_Rev01: Zniffer timeout increased.
- S2_AbortBootstrapWithoutUnauth_Rev01, S2_GrantedS2UnauthClass_Rev01,
  S2_SISMaySupportCSA_Rev01 fixed which sometimes had no result when DUT data
  did not match: ZCP-based: Form Fail. / DUT-based: Pass (does not apply).
- S2_UnauthLearnModeECDHKeyPair_Rev01: Clarified test description and fail
  messages.

CTT Scripts 33
--------------

NEW:

- Battery scripts, new revisions: Workaround added in
  'Interactive_WaitForBatteryLowReport' in order to not consider Battery
  Reports before having clicked 'OK'.
- CentralSceneCmdClassV3_Rev07: 'Interactive_CheckSupportedScenes' and
  'Interactive_CheckSlowRefresh': Workaround added sending / expecting ZWP
  Info Get / Report in order to not confuse the next expected Central Scene
  Notification with the previously expected one.
- NotificationCmdClassV8_Rev19: New script revision containing new events in
  accordance with 2023B.

FIXED:

- Meter v2..v6 scripts: Increased global load delay to a default value of 60
  seconds within recent revision each.
- UserCodeCmdClassV2_Rev05 + V1_Rev08: Fixed field names for Remaining Lock
  Time in Door Lock Operation Report in accordance with Z-Wave XML 2.13.0.


CTT 3.5.2 (2023-07-25) [2023A]
==============================

> NOTICE WHEN UPGRADING TO VERSION 3.5:
>
> Due to a new installer it is recommended to manually uninstall older CTT
> versions before installing version 3.5.

NEW:

- Tests have been added in regards to the 2023A certification program update.
- Command Classes have been added to ZATS and Z-Wave DLL in accordance with
  Z-Wave XML 2.13.0.
- An option to manually repair a project considering the recent DUT
  interview data has been added to Project > Repair Project. If the DUT
  interview data was missing or incorrect during project creation, this
  option can be used to automatically add or remove tests which require
  correct advertisement of CCs in the DUT data for CTT to know on which End
  Point those tests belong (in particular tests from the 'Scripts' group).
- Script import now has an option to offer all (older) revisions.
- A Log History feature has been added to the Test Reporter.

CHANGED:

- Switched to NSIS installer.
- Previous DUT data is restored when inclusion / interview is aborted.
- Remember up to 18 recently opened projects.
- Within CTT the serial Zniffer will only still use the classic counterpart
  region if the desired LR region is not supported by the particular Zniffer
  firmware. (Serial LR Zniffer is not implemented for ZATS tests, yet.)
- Warn (not error) if script run is started without any DUT.
- Update servers adjusted to Z-Wave Alliance Portal server rather than Legacy
  Portal server.
- Provide portal URLs to MKL beta servers in CTT alpha and beta versions.

FIXED:

- Z-Wave DLL, Network View Point: Request timeout has been decreased in order
  to prevent Wake Up nodes from already sleeping when continuing
  communication.
- Fixed exception in DUT vs. Form Comparison when the DUT advertises an
  unknown combination of Device Classes on End Point 1 or higher which does
  not match any known ZWP or ZWPv2 Device Type.
- Fixed exception in DUT vs. Form Comparison when the ZCP form template
  contains empty values for a specific Command Class.
- Fixed exception when replication was done using the advanced inclusion menu.
- Fixed possible exception when removing a script while the Test Case
  Explorer tree was loading.
- Documentation: Old double-click functions in Test Case Explorer have been
  removed.
- Replaced all remaining occurrences of 'Silicon Labs' with 'Z-Wave Alliance'.
- Fixed misleading DUT interview log output for Central Scene CC with
  identical scenes.
- Fixed manually stopping script execution while waiting for Wake Up
  Notification.
- Fixed an issue where sometimes user scripts were not actually saved in an
  LR project.
- Duplicated LR scripts are no longer displayed in the diff menu.
- Fixed a possible exception with tool tips.
- Numerous fixes and improvements for existing Test Cases (ZATS tests and
  CTT scripts) have been implemented.


CTT 3.4.1 (2023-01-30) [2022B]
==============================

> NOTICE WHEN UPGRADING TO VERSION 3.4:
>
> Projects created or saved with CTT v3.4 are not compatible with older CTT
> versions. Whereas, projects created with versions older than 3.4 can be
> loaded in CTT v3.4 and will be automatically transformed into recent
> projects.
>
> Due to substantial changes of the test environment most test results of
> existing projects created with older versions will be reset to 'pending'
> when loaded in CTT v3.4. Thus, it is recommended to not switch to CTT v3.4
> during an ongoing Self-Certification.

NEW:

- Test Cases (ZATS tests and CTT scripts) have been added in regards to the
  2022B AWG and CSWG specifications and certification program update.
- Z-Wave Long Range end devices (DUT) can be included by the CTT Controller
  via SmartStart Long Range inclusion.
- Zniffer PTI is added and needed as Zniffer in a Long Range network.
- Firmware for Zniffer PTI firmware has been added.
- Former manual Long Range tests for end devices have been implemented as
  'Inclusion' and 'Automatic' tests.
- CTT is able to detect serial APIs even if sleeping (e.g. emulated
  non-listening end device) by trying to soft reset the dev board.
- New revisions are added to DUT-based projects.

CHANGED:

- CTT's project system has been reworked in regards to the Long Range
  integration for end devices. If the DUT has been selected (ZCP Form-based
  or DUT-based in CTT) to be a Long Range end device, the CTT project will
  become a Long Range project and require certain tests to be run in either
  classic or Long Range mode, or both. The 'Classic Tests' and 'Long Range
  Tests' tabs have been added as parent tabs - each contains the known test
  groups 'Automatic', 'Interactive' etc. as child tabs. Recent inclusion
  state and respective required hardware are considered.
- Exclusionary terms have been removed within CTT, ZATS, Z-Wave DLL, Scripts
  and recent ZATS Test Cases - also technical names, e.g. end node Role
  Types. Their previous terms have been kept in old Test Case revisions in
  order to match the respective old version of the specifications and
  certification form revisions.
- ZATS (Z-Wave Automated Test System) and Z-Wave DLL have been updated.
- Provided firmware files (serial API and bootloaders) for CTT devices have
  been updated for 700 and 800 series (7.18.1).

FIXED:

- Fixed an issue where for some 'Interactive' tests the security key folder
  in the log had remained empty.
- Fixed adding DUT-based Test Cases with Device Type filter.
- The update message box will stay in foreground.
- Numerous fixes and improvements for existing Test Cases (ZATS tests and
  CTT scripts) have been implemented.


CTT 3.3.1 (2022-06-30) [2022A]
==============================

NEW:

- Test Cases (ZATS tests and CTT scripts) have been added for the 2022A
  specification and certification program update.
- Support for CTT Controller(s) and CTT End Device(s) using serial API on 800
  series hardware has been added.
- CTT log and button control strings are mirrored to standard output
  (stdout).
- New revisions added to DUT-based projects.

CHANGED:

- Less CTT hardware is required for 'S2 Certification': only two CTT
  Controllers (at least one bridge) and two CTT End Devices (before three and
  three).
- Improved and equalized log and buttons.
- ZATS (Z-Wave Automated Test System) and Z-Wave Command Class XML have been
  updated.
- Provided firmware files (serial API) for CTT devices have been updated for
  500 series (6.84.00 [6.10]) as well as 700 and 800 series (7.17.2).
  Bootloaders have been added.

FIXED:

- Previously known issue with controller serial API 7.15+ has been fixed. The
  Node Base Type is now set at every serial API restart in order to support
  both 8-bit and 12-bit Node IDs.
- Test Reporter: Logs are now opened being scrolled up to the beginning.
- Fixed lookup for mandatory Command Classes vs. Device and Role Type matrix.
  Fixed Sound Switch DTv2 lookup.
- Documentation: Fixed to be available offline. Content updated referring to
  Simplicity Studio v5 as well as for 800 series devices.
- Numerous fixes and improvements for existing Test Cases (ZATS tests and CTT
  scripts) have been implemented.


CTT 3.2.4 (2022-02-03)
======================

CHANGED:

- QR Code Data is kept in Project Properties when re-including the same
  device.
- Test Reporter: Minimum size for Test Case Input and Results added.
- Form vs. DUT Compare is now showing the v1 Command Class name instead of
  'Unknown' if the advertised version is not existent but the CC exists.
- Using serial APIs on 800 series hardware as CTT Controller or CTT End
  Device is not implemented, yet. Thus, in this CTT version serial devices
  with 800 series chipsets have been removed from the list of selectable
  serial devices. (800 series DUTs can be tested though.)

FIXED:

- Update process for Script updates fixed.
- Fixed CTT device advertisement for Inclusion Controller Command Class
  within Test Cases where DUT has Learn Mode and is Inclusion Controller.
- Potential issue fixed when connecting to the CTT Controller too often.
- Fixes and improvements for existing Test Cases and Scripts have been
  implemented.


CTT 3.2.3 (2021-12-21) [2021D]
==============================

> NOTICE WHEN UPGRADING TO VERSION 3.2:
>
> Since version 3.2 CTT is a Z-Wave Alliance tool. Installation, settings and
> documents folders have been adjusted from 'Silicon Labs' to 'Z-Wave
> Alliance'. Settings from CTT v3.1 are automatically transferred to the CTT
> v3.2+ version.

NEW:

- Test Cases and Scripts have been added in accordance with the 2021D
  specifications release.
- A 'Scan QR' button has been added to the QR-Code Data section in Project
  Properties > DUT Interview Data.
- A new filter setting for the ZCP result upload has been added. It allows to
  select all form items where results are pending on ZCP. The Pending state
  is now displayed in the ZCP result column in the Form Item View (instead of
  keeping the column empty in such a case).
- A button to the Project Properties > Configure Network windows has been
  added to the Project Start page and the main menu bar.

CHANGED:

- CTT 3.2 is now a Z-Wave Alliance tool. Installation, settings and document
  folders have been adjusted. Settings from older Silabs CTT versions are
  imported.
- The default project folder has been moved from AppData to [User]/Documents/
  (...).
- If the DUT includes the CTT Controller in Project Properties > Configure
  Network, the CTT is set to SSC RT in order to not get the SIS role
  assigned. This ensures a non-SIS DUT will keep the Primary Controller
  network role.
- The Command Classes XML file has been updated to version 2.9.0. The updated
  XML contains the fixed Command name for the Meter Table Capability Report
  in the Meter Table Command Class.
- The Form Item View window is opened automatically when a Portal/ZCP-based
  project is loaded.
- In the CTT UI, help pages and in most Test Case and Script log output
  inclusionary terms like 'End Device' is now used. Note that in
  specification text and some hardware related strings the terms have not yet
  been adjusted.
- A Nonce Exchange is triggered whenever a Script run starts. This ensures
  that the recorded Zniffer trace can be decrypted.
- Network keys are saved in the Script execution's log folder (same as for
  each executed Test Case).
- Loading another project will reset/empty the Error Log window.
- The search function in Wizard step 'Select Portal Case' works case-
  insensitive now. The filter function is now also applied if the Wizard is
  moved back to this step.
- The warning messages when selecting a Portal case have been adjusted based
  on what permissions a user has and in what phase a Portal case currently
  is.
- The link to the CTT update page that is displayed in the message log window
  when a CTT update is available now contains the correct Portal URL based on
  what Portal credentials have been used in CTT (Z-Wave Alliance Portal or
  Legacy Portal).
- The Serial API firmware files from CTT Controllers and End Devices have
  been updated to SDK version 7.16.3. They are located in `[User]\Documents\
  Z-Wave Alliance\Z-Wave CTT 3\CTT Device Firmwares`.

FIXED:

- Scripts do not accept expected Commands on lower security schemes and these
  Commands will not change the security level anymore on which the script
  sends its own commands.
- A potential memory leak when running the Firmware Update Meta Data Cmd
  Class scripts has been fixed.
- When opening another DUT-based project the DUT Test Case Selection window
  is closed correctly.
- Manual detection and verification of the Simplicity Commander path on the
  Options dialog has been fixed and improved.
- Test Cases for supported Command Classes are now correctly assigned to the
  End Point nodes in the Test Case Explorer.
- The Form-DUT Compare window is updated automatically after a Portal case
  re-sync.
- A bug where Test Cases used older versions of the Command Classes XML file
  has been fixed.
- A bug has been fixed where the CTT got into a blocked state after starting
  a Test Case without any selected hardware.
- Double clicking on Script syntax or execution errors listed in the Error
  Log window will navigate to the script code position again. This function
  was broken in version 3.1.3.
- The Load Default Layout function has been fixed.
- The context menu entries have been fixed in Test Case Explorer. Sometimes
  wrong menu labels appeared after jumping between Test Case categories.
- The References window is now always updated when another Project is loaded.


CTT 3.1.3 (2021-03-26)
======================

NEW:

- Created a Project Start Page with links and explanation to most important
  Project tools and views.
- List with required Z-Wave hardware in Test Reporter added, including
  current state (available / missing).
- List of missing Test Case hardware is shown in Property view at the bottom
  right of the CTT.
- CTT allows to setup and use up to three Controller and three Slave hardware
  devices (used for additional S2 Test Cases).
- Project Properties > Serial Devices dialog adjusts automatically to the
  number of required hardware devices (based on what Test Cases require).
- CTT is able to use different Portal instance addresses when creating
  Portal-based projects, the list of available Portal addresses can be
  modified remotely.
- Added Previous/Next Error buttons to Output Log view in Test Reporter.
- Added path to Simplicity Commander to Options dialog so it can be selected
  manually if auto detection failed.
- Added a new set of S2 certification Tests Cases (S2C) for Controllers that
  are not based on Z/IP Gateway.
- Added new set of Z-Wave Long Range specific Wiki page Test Cases (LR).

CHANGED:

- DUT vs. Form Comparison: Advertised DUT Command Class names are shown even
  if the Command Class version is not known to CTT (not included in Command
  Class XML file).
- Link to ‘Open Official Solution' has been removed from Start Page.
- CTT menus and context menus have been cleaned up.
- Script sequences are now also checked and executed when a Command Class
  script is checked.
- Log window is switched to Output tab when any log output is added. Minimum
  size for log window is enforced.

FIXED:

- Security status of Basic Command Class in DUT is handled correctly now.
- Fixed a crash when Portal and DUT End Points differed.
- Fixed an exception when the CTT main Controller connection was established
  more than 127 times.
- Project load the correct Command Classes XML file for script modifications.
- Fixed a memory leak that happened if CTT received frames with Transport
  Encapsulation (e.g. during script execution).
- A large number of fixes and improvements in Scripts and Test Cases.


CTT 3.0.7 (2020-12-29)
======================

> NOTICE WHEN UPGRADING TO VERSION 3:
>
> CTT v2 is obsoleted. CTT v3 has major changes compared to CTT v2. Please
> consult the 'Introduction' section of the help pages to learn how to use
> CTT v3.
>
> Solutions / projects from CTT v2 are NOT compatible with CTT v3. A new
> project has to be created in CTT v3 for a Device Under Test (DUT).
>
> CTT v3 is installed in parallel to any old CTT v2 installation. This means
> CTT v2 can still be used to load old CTT v2 solutions. Another way to use
> custom scripts from CTT v2 is to manually copy the source code of a CTT v2
> script into a newly created CTT v3 script.
>
> If using the Z-Wave Plus v2 (ZWPv2) program, CTT v3 is able to download the
> set of required Self-Certification Test Cases from the Z-Wave Certification
> Portal (ZCP) and to upload Test Case results back to the ZCP. ZWPv2 form
> revision 5 or newer is required.
>
> If using the Z-Wave Plus (version 1) program, Test Cases are based on
> interview data of the DUT. This set of Test Cases may not be complete in
> regards to verifying Z-Wave certification requirements.

NEW:

- First public release.
