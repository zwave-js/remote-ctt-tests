Z-Wave Compliance Test Tool (CTT) - Known Issues
================================================

If you encounter any bug or issue with the CTT which is not listed here, please
contact:

- certadmin@z-wavealliance.org or
- support@mk-logic.de


CTT 3.10.10 (2025-08-25) [2025A]
================================

KNOWN ISSUES:

- For CTT hardware, and in particular for the CTT End Device, the CHIP MUST BE
  ERASED before flashing the Serial API firmware.
- Since CTT 3.4 / 800 series End Device firmware 7.18 occasionally the CTT /
  ZATS End Device does not answer a KEX Get during S2 bootstrapping so it times
  out. In the majority of cases this is not reproducible and will work when
  running the test again. Please make sure to have installed the latest
  security firmware on the 800 series development board: In Simplicity Studio
  select the dev board > Overview > General Information > Secure FW.
- In rare cases the CTT Script engine gets into a state where one received
  command from the DUT is taken for multiple subsequent EXPECT statements.
  If this happens, please reset and re-include the DUT in 'Project
  Properties' > 'Configure Network' and run the script again.
- Trying to set the RF region to UZB7 sticks flashed with controller firmware
  7.19 or newer may cause a failure message, even if it actually worked. The
  recommended firmware for CTT devices is provided in `[User]\Documents\
  Z-Wave Alliance\Z-Wave CTT 3\CTT Device Firmwares`.
- If the DUT interview data is missing or incorrect during project creation or
  update, scripts and few ZATS tests which only run on a particular Root
  Device / End Point if a Command Class is supported, those tests cannot be
  automatically added to the CTT project if the Command Class is not advertised
  on the respective End Point. It may also happen that scripts for CCs listed
  in the ZCP Form are added to the root device while not supported there. The
  option 'Project' > 'Repair Project' can be used to consider the recent DUT
  data to add or remove those tests.
- CTT Controller as a test tool will only advertise support for a very limited
  minimum of CCs, unless used within a ZATS test run (e.g. no Version CC, no
  Supervision CC during inclusion and script runs).
- Rarely, the DUT interview does not learn all supported / granted security
  schemes. In this case, start the interview (or inclusion) again. The issue
  mostly happens if the DUT answers relatively slowly so that Security Learning
  takes more than a second.
- The Zniffer PTI has no API and cannot be detected. Accordingly, the IP
  address must be specified manually. Also, it cannot be detected if the board
  is already used by another application. Only one connection is possible. Be
  careful, the last application which connects will get the traffic.
- The selection of scripts and their sequences are synchronized between Classic
  and Long Range tabs and cannot be saved individually.
- If a CTT project is transformed from a non-Long Range project into a Long
  Range project, results of Classic scripts are also reset to 'pending'.
- If a script execution is stopped, the current test sequence gets the 'passed'
  state instead of 'pending' or 'aborted'.
- Write access on CTT project files must not be blocked for CTT and its ZATS
  tests console by any other program. For example, CTT projects shall not be
  saved within actively syncing cloud service folders (like Dropbox). It may
  block tests from writing log files causing unexpected behavior.
- Loading long logs into the Test Reporter might take quite some time.
- Script editor: Find/Replace function only finds statements below the cursor
  and only the first occurrence in a line.
- Form View: Portal result status 'n/a' is shown differently in CTT.
- Test Reporter is closed when uploading results.
- DUT-based projects: S0-only nodes are not considered. S2 tests will still be
  added.

POSSIBLE ISSUES SEEN IN PREVIOUS VERSIONS:

- 700 series UZB sticks with a 7.13 firmware will not work correctly if power
  save mode is switched on in Windows device manager settings. They fall to
  sleep after a few seconds and will not wake up anymore without reconnecting
  them. As a workaround disable the following option: Device Manager > Ports
  (COM & LPT) > Silicon Labs CP210x USB to UART Bridge (COMxx) > Properties >
  Power Management > Allow the computer to turn off [disabled]. However, even
  then, UZB7 sticks must be reconnected once after starting the computer. In
  any case it is highly recommended to use the firmware for the CTT hardware
  provided in `[User]\Documents\Z-Wave Alliance\Z-Wave CTT 3\CTT Device
  Firmwares`.
- It happened on startup that CTT did not get past the Simplicity Commander
  Check at startup. Most probably this was an UI issue only. If restarting
  CTT does not solve it, the user config, possibly inherited from older CTT
  versions, should be checked in `[User]\AppData\Local\Z-Wave_Alliance\
  ZWaveCTT.exe[...]\[3.x.y.z]\user.config`.

ZATS Test Console, version 16 / ZATS Cert Test Cases, version 22
----------------------------------------------------------------

KNOWN ISSUES:

- General: CRC16: The ZATS Controller does not answer as asked.
- General: If a Controller-DUT does not have the CSC Role Type, some tests
  requiring the DUT to perform S2 bootstrapping might not work correctly
  because the DUT must assign the SIS role to the CTT Controller which has CSC
  RT so that the DUT (i.e. Real Primary) becomes an Inclusion Controller
  instead of staying Primary.
- General: Some tests do not test S0-only devices correctly but expect S2 to
  be supported.
- CC Support Implementations: Supervision results are not combined in case of
  Multi Channel Bit Addressing.
- CPD_ConfigurationParameterData_Rev01: Does not capture reports to follow if
  sent very fast.
- S2C: In some "S2 Certification" tests the ZATS Controller is advertising
  the Supervision CC in its NIF despite actually not supporting it.

POSSIBLE ISSUES SEEN IN PREVIOUS VERSIONS:

- Z/IP Gateways with 7.13.1 firmware or older might experience S2
  synchronization errors due to decryption errors. It is highly recommended to
  use a newer Z/IP Gateway version.
- When using CTT to test a Controller DUTs based on Z/IP Gateway in some tests
  (e.g. S0_ControllerCanIncludeS0Devices_Rev01) Nonce Gets from the DUT may
  not be answered directly after bootstrapping. This happens because Z/IP
  Gateway starts the device interview too quickly and before the Test Case is
  ready. In this case try to run the Test Case again or test the requirement
  manually.

Official CTT Script Solution (OSV), version 42
----------------------------------------------

KNOWN ISSUES:

- BasicMappingForWinCovPosAndEpAwareZWPv2_Rev01 contains no test sequences. Do
  test manually instead.
- Multilevel Switch or Color Switch scripts with 'Duration' test sequences must
  be calibrated but may still be too strict. If they are testing recommended
  durations, try to get as close as possible according to the DUT's hardware
  capabilities. Then consider it passed.
- UserCodeCmdClassV2_Rev05: DUT must support 10 digit codes. But if it does
  not, the error message may be misleading.
- WakeUpCmdClassV2_Rev10/11 + V3: When DUT Interval Step is 0, Supervision test
  sequence may choose a 'not allowed' interval value which actually is allowed.
  In this case, use a 'not allowed' value manually (copy as user script).
